var express = require("express");
var app = express();

const jsonData = require("./users.json");

app.get("/", function (req, res) {
  res.send("Welcome to 101223478_comp3123_assig1");
});

app.get("/user", function (req, res) {
  const uid = parseInt(req.query.uid);
  let result = jsonData.find(user=> user.id === uid)
  if(!result){
    result = {"message": "No user found"}
  }

  res.json(result);
});

app.get("/users/all", function (req, res) {
  res.json(jsonData);
});

var server = app.listen(8082, function () {
  var host = server.address().address;
  var port = server.address().port;
  console.log("101223478_comp3123_assig1 app listening at http://%s:%s", host, port);
});
