module.exports = {
    content: ['./build/index.html', './build/**/*.js', './build/**/*.html'],
    css: ['./build/**/*.css'],
    fontFace: true,
    keyframes: true,
    variables: true
}