//import { fstat } from 'node:fs';
//import fs from 'fs';
//import * as Fs from 'fs'
//import fs from 'fs'
const fs = require('fs');
const path = require('path')

if(!fs.existsSync("Logs")) {
    fs.mkdirSync("Logs");
}
process.chdir("Logs");


for(let i = 0; i < 10; i++) {
  
    const filename = `log${i}.txt`;
    
    fs.writeFile(filename, 'some text', (err) => {
       
        if (err) {
        
            throw err;
        }
    });
  
    console.log(filename);
}
