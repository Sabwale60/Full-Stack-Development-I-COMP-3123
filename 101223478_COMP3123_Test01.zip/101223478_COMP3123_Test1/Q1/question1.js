
    function lowerCaseWords(arr) {
        return new Promise((resolve, reject) => {
            let result = arr.filter(item => (typeof item === "string"))  
            lowerArr = result.map(w => w.toString().toLowerCase())
            resolve(lowerArr)
        })
    }
    
    const mixedArray = ['PIZZA', 10, true, 25, false, 'Wings']
    lowerCaseWords(mixedArray)
        .then(result => console.log(result))
        .catch(error => console.log(error))
    